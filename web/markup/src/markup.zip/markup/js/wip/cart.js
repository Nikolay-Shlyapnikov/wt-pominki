const cartCounter = () => {

    localStorage.filter((key)=>{
        return 
    });
  
}
export {cartCounter};